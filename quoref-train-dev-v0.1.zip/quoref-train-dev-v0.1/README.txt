Quoref: A Reading Comprehension Dataset with Questions Requiring Coreferential Reasoning
----------------------------------------------------------------------------------------

This directory contains the Quoref dataset split into train and dev sets. The
test set is not included in this package. The format of each json file is the
same as that of SQuAD, except that the "answers" field can be a list of
multiple spans.

Please read the paper for more details:
https://www.semanticscholar.org/paper/Quoref%3A-A-Reading-Comprehension-Dataset-with-Dasigi-Liu/315642b4698f327ce1f7a76e8973f34f9b54cecd
